import numpy as np

from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.ensemble import RandomForestClassifier

from skopt import BayesSearchCV


# Load dataset
data = load_breast_cancer()
X = data.data
y = data.target


# Train-test split
X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.2,
    random_state=42
)


# Define model
model = RandomForestClassifier(random_state=42)


# Define hyperparameter search space
param_space = {
    'n_estimators': (50, 300),
    'max_depth': (3, 20),
    'min_samples_split': (2, 20),
    'min_samples_leaf': (1, 10)
}


# Bayesian Optimization
bayes_search = BayesSearchCV(
    estimator=model,
    search_spaces=param_space,
    n_iter=25,              # Number of optimization steps
    cv=3,
    scoring='accuracy',
    n_jobs=-1,
    random_state=42
)


# Run optimization
bayes_search.fit(X_train, y_train)


# Results
print("Best Hyperparameters Found:")
print(bayes_search.best_params_)

print("\nBest Cross-Validation Accuracy:")
print(bayes_search.best_score_)

# Test accuracy
test_accuracy = bayes_search.score(X_test, y_test)

print("\nTest Set Accuracy:")
print(test_accuracy)
