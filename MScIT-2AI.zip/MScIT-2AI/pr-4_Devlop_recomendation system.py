import numpy as np
import pandas as pd
import tensorflow as tf

from tensorflow.keras.models import Model
from tensorflow.keras.layers import (
    Embedding,
    Flatten,
    Dense,
    Input,
    Concatenate
)
from tensorflow.keras.optimizers import Adam


# Sample dataset
data = {
    'user_id': [1, 1, 1, 2, 2, 3, 3, 3, 4, 4],
    'item_id': ['A', 'B', 'C', 'A', 'C', 'A', 'B', 'C', 'B', 'C'],
    'rating': [5, 4, 3, 4, 5, 3, 2, 5, 5, 3]
}

df = pd.DataFrame(data)


# Map user_id and item_id to integers
user_map = {user: idx for idx, user in enumerate(df['user_id'].unique())}
item_map = {item: idx for idx, item in enumerate(df['item_id'].unique())}

df['user_id'] = df['user_id'].map(user_map)
df['item_id'] = df['item_id'].map(item_map)


# Features and labels
X = df[['user_id', 'item_id']].values
y = df['rating'].values


# Define model inputs
user_input = Input(shape=(1,))
item_input = Input(shape=(1,))


# Embedding layers
user_embedding = Embedding(
    input_dim=len(user_map),
    output_dim=10
)(user_input)

item_embedding = Embedding(
    input_dim=len(item_map),
    output_dim=10
)(item_input)


# Flatten embeddings
user_embedding = Flatten()(user_embedding)
item_embedding = Flatten()(item_embedding)


# Concatenate user & item embeddings
merged = Concatenate()([user_embedding, item_embedding])


# Fully connected layers
dense = Dense(128, activation='relu')(merged)
dense = Dense(64, activation='relu')(dense)
output = Dense(1)(dense)


# Build and compile the model
model = Model(
    inputs=[user_input, item_input],
    outputs=output
)

model.compile(
    optimizer=Adam(),
    loss='mean_squared_error'
)


# Train the model
model.fit(
    [X[:, 0], X[:, 1]],
    y,
    epochs=10,
    batch_size=2,
    verbose=1
)


# Recommendation function
def recommend(user_id, top_n=3):
    # Get all item indices
    all_items = list(item_map.values())

    # Create input arrays
    user_input_data = np.array(
        [user_map[user_id]] * len(all_items)
    )
    item_input_data = np.array(all_items)

    # Predict ratings
    predictions = model.predict(
        [user_input_data, item_input_data]
    )

    # Sort items by predicted rating (descending)
    item_ids_sorted = np.argsort(
        predictions.flatten()
    )[::-1]

    # Top-N items
    recommended_item_ids = item_ids_sorted[:top_n]

    # Convert back to original item labels
    recommended_items = [
        list(item_map.keys())[
            list(item_map.values()).index(idx)
        ]
        for idx in recommended_item_ids
    ]

    return recommended_items


# Example usage
user_id = 1
recommended_items = recommend(user_id)

print(
    f"Top 3 recommendations for user {user_id}: {recommended_items}"
)
