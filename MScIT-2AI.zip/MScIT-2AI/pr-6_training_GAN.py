import tensorflow as tf
from tensorflow.keras import layers
import numpy as np
import matplotlib.pyplot as plt
import os


# Set random seed for reproducibility
np.random.seed(42)
tf.random.set_seed(42)


# Load and preprocess MNIST dataset
(x_train, _), (_, _) = tf.keras.datasets.mnist.load_data()

x_train = x_train.astype("float32")

# Normalize images to [-1, 1]
x_train = (x_train - 127.5) / 127.5
x_train = np.expand_dims(x_train, axis=-1)  # (28, 28, 1)


# Parameters
latent_dim = 100
batch_size = 64
epochs = 10000
save_interval = 1000


# Generator model
def build_generator():
    model = tf.keras.Sequential()

    model.add(layers.Dense(128 * 7 * 7, input_dim=latent_dim))
    model.add(layers.LeakyReLU(0.2))
    model.add(layers.BatchNormalization(momentum=0.8))

    model.add(layers.Reshape((7, 7, 128)))

    model.add(layers.Conv2DTranspose(
        128, kernel_size=3, strides=2, padding="same"
    ))
    model.add(layers.LeakyReLU(0.2))
    model.add(layers.BatchNormalization(momentum=0.8))

    model.add(layers.Conv2DTranspose(
        64, kernel_size=3, strides=2, padding="same"
    ))
    model.add(layers.LeakyReLU(0.2))
    model.add(layers.BatchNormalization(momentum=0.8))

    model.add(layers.Conv2DTranspose(
        1, kernel_size=3, strides=1, padding="same", activation="tanh"
    ))

    return model


# Discriminator model
def build_discriminator():
    model = tf.keras.Sequential()

    model.add(layers.Conv2D(
        64, kernel_size=3, strides=2, padding="same",
        input_shape=(28, 28, 1)
    ))
    model.add(layers.LeakyReLU(0.2))
    model.add(layers.Dropout(0.25))

    model.add(layers.Conv2D(
        128, kernel_size=3, strides=2, padding="same"
    ))
    model.add(layers.LeakyReLU(0.2))
    model.add(layers.Dropout(0.25))

    model.add(layers.Flatten())
    model.add(layers.Dense(1, activation="sigmoid"))

    return model


# GAN model
def build_gan(generator, discriminator):
    discriminator.trainable = False

    gan_input = layers.Input(shape=(latent_dim,))
    x = generator(gan_input)
    gan_output = discriminator(x)

    gan = tf.keras.Model(gan_input, gan_output)
    return gan


# Compile models
discriminator = build_discriminator()
discriminator.compile(
    optimizer=tf.keras.optimizers.Adam(0.0002, beta_1=0.5),
    loss="binary_crossentropy",
    metrics=["accuracy"]
)

generator = build_generator()
gan = build_gan(generator, discriminator)
gan.compile(
    optimizer=tf.keras.optimizers.Adam(0.0002, beta_1=0.5),
    loss="binary_crossentropy"
)


# Save generated images
def save_generated_images(epoch, examples=10, dim=(1, 10), figsize=(10, 1)):
    noise = np.random.normal(0, 1, (examples, latent_dim))
    generated_images = generator.predict(noise)

    generated_images = (generated_images + 1) / 2.0

    plt.figure(figsize=figsize)

    for i in range(examples):
        plt.subplot(dim[0], dim[1], i + 1)
        plt.imshow(generated_images[i, :, :, 0], cmap="gray")
        plt.axis("off")

    plt.tight_layout()
    plt.savefig(f"gan_generated_image_{epoch}.png")
    plt.close()


# Training function
def train_gan(epochs, batch_size, save_interval):
    half_batch = batch_size // 2

    valid = np.ones((half_batch, 1))
    fake = np.zeros((half_batch, 1))

    for epoch in range(epochs):

        # Train Discriminator
        idx = np.random.randint(0, x_train.shape[0], half_batch)
        real_images = x_train[idx]

        noise = np.random.normal(0, 1, (half_batch, latent_dim))
        generated_images = generator.predict(noise)

        d_loss_real = discriminator.train_on_batch(real_images, valid)
        d_loss_fake = discriminator.train_on_batch(generated_images, fake)
        d_loss = 0.5 * np.add(d_loss_real, d_loss_fake)

        # Train Generator
        noise = np.random.normal(0, 1, (batch_size, latent_dim))
        g_loss = gan.train_on_batch(noise, np.ones((batch_size, 1)))

        # Save progress
        if epoch % save_interval == 0:
            print(
                f"{epoch}/{epochs} "
                f"[D loss: {d_loss[0]} | D acc: {100 * d_loss[1]}] "
                f"[G loss: {g_loss}]"
            )
            save_generated_images(epoch)


# Train the GAN
train_gan(epochs, batch_size, save_interval)
