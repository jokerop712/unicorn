import torch
import torch.nn as nn
import torch.optim as optim
import torchvision
import torchvision.transforms as transforms
import matplotlib.pyplot as plt
import os
import torchvision.utils as vutils
from torch.utils.data import DataLoader


# Generator Model
class Generator(nn.Module):
    def __init__(self):
        super(Generator, self).__init__()

        self.fc1 = nn.Linear(100, 256)
        self.fc2 = nn.Linear(256, 512)
        self.fc3 = nn.Linear(512, 1024)
        self.fc4 = nn.Linear(1024, 784)

        self.relu = nn.ReLU()
        self.tanh = nn.Tanh()

    def forward(self, z):
        x = self.relu(self.fc1(z))
        x = self.relu(self.fc2(x))
        x = self.relu(self.fc3(x))
        x = self.tanh(self.fc4(x))  # Output in range [-1, 1]
        return x.view(-1, 1, 28, 28)


# Discriminator Model
class Discriminator(nn.Module):
    def __init__(self):
        super(Discriminator, self).__init__()

        self.fc1 = nn.Linear(784, 1024)
        self.fc2 = nn.Linear(1024, 512)
        self.fc3 = nn.Linear(512, 256)
        self.fc4 = nn.Linear(256, 1)

        self.leaky_relu = nn.LeakyReLU(0.2)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        x = x.view(-1, 784)
        x = self.leaky_relu(self.fc1(x))
        x = self.leaky_relu(self.fc2(x))
        x = self.leaky_relu(self.fc3(x))
        x = self.sigmoid(self.fc4(x))
        return x


# Load MNIST dataset
def load_data():
    transform = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize((0.5,), (0.5,))
    ])

    train_dataset = torchvision.datasets.MNIST(
        root="./data",
        train=True,
        download=True,
        transform=transform
    )

    train_loader = DataLoader(
        train_dataset,
        batch_size=64,
        shuffle=True
    )

    return train_loader


# Train the GAN
def train_gan(
    generator,
    discriminator,
    train_loader,
    num_epochs=50,
    lr=0.0002,
    beta1=0.5,
    output_dir="generated_images"
):
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    criterion = nn.BCELoss()

    optimizer_g = optim.Adam(
        generator.parameters(),
        lr=lr,
        betas=(beta1, 0.999)
    )

    optimizer_d = optim.Adam(
        discriminator.parameters(),
        lr=lr,
        betas=(beta1, 0.999)
    )

    for epoch in range(num_epochs):
        for i, (real_images, _) in enumerate(train_loader):

            batch_size = real_images.size(0)

            real_labels = torch.ones(batch_size, 1)
            fake_labels = torch.zeros(batch_size, 1)

            # ---------------------
            # Train Discriminator
            # ---------------------
            optimizer_d.zero_grad()

            output_real = discriminator(real_images)
            loss_real = criterion(output_real, real_labels)

            z = torch.randn(batch_size, 100)
            fake_images = generator(z)
            output_fake = discriminator(fake_images.detach())
            loss_fake = criterion(output_fake, fake_labels)

            loss_d = loss_real + loss_fake
            loss_d.backward()
            optimizer_d.step()

            # ---------------------
            # Train Generator
            # ---------------------
            optimizer_g.zero_grad()

            output_fake_g = discriminator(fake_images)
            loss_g = criterion(output_fake_g, real_labels)
            loss_g.backward()
            optimizer_g.step()

            if (i + 1) % 100 == 0:
                print(
                    f"Epoch [{epoch+1}/{num_epochs}], "
                    f"Step [{i+1}/{len(train_loader)}], "
                    f"D Loss: {loss_d.item():.4f}, "
                    f"G Loss: {loss_g.item():.4f}"
                )

        # Save generated images every 10 epochs
        if (epoch + 1) % 10 == 0:
            with torch.no_grad():
                fake_images = generator(torch.randn(64, 100))
                vutils.save_image(
                    fake_images,
                    os.path.join(output_dir, f"epoch_{epoch+1}.png"),
                    nrow=8,
                    normalize=True
                )
                print(
                    f"Generated images saved to {output_dir}/epoch_{epoch+1}.png"
                )


# Main execution
if __name__ == "__main__":
    train_loader = load_data()

    generator = Generator()
    discriminator = Discriminator()

    train_gan(generator, discriminator, train_loader)

    torch.save(generator.state_dict(), "generator.pth")
    torch.save(discriminator.state_dict(), "discriminator.pth")

    print("Models saved as 'generator.pth' and 'discriminator.pth'")
